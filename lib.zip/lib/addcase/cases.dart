import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'caseswidget.dart';


class CasePage extends StatefulWidget {
  const CasePage({Key? key}) : super(key: key);

  @override
  State<CasePage> createState() => _CasePageState();
}

class _CasePageState extends State<CasePage> {
  late String lawyerId;
  List<Map<String, dynamic>> openCases = [];
  List<Map<String, dynamic>> openCasesLists = [];
  List<Map<String, dynamic>> closedCases = [];
  List<Map<String, dynamic>> closedCasesLists = [];
  List<Map<String, dynamic>> upcomingCases = [];
  List<Map<String, dynamic>> upcomingCasesLists = [];
  bool isListViewVisible = false;
  int selectedCaseIndex = -1;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    await fetchLawyerId();
    openCasesList();
    closedCasesList();
    upcomingCasesList();
  }

  Future<void> fetchLawyerId() async {
    final user = FirebaseAuth.instance.currentUser;
    final userDoc =
        FirebaseFirestore.instance.collection('lawyers').doc(user!.uid);
    final userData = await userDoc.get();
    setState(() {
      lawyerId = userData['lawyerId'];
    });
  }

  void openCasesList() {
    FirebaseFirestore.instance
        .collection('addcase')
        .where('team', arrayContains: lawyerId)
        .where('casetype', isEqualTo: 'open')
        .snapshots()
        .listen((snapshot) {
      List<Map<String, dynamic>> openCases = snapshot.docs
          .where((doc) => doc['team'][0] == lawyerId)
          .map((doc) => doc.data())
          .toList();
      setState(() {
        openCasesLists = openCases;
      });
    });
  }

  void closedCasesList() {
    FirebaseFirestore.instance
        .collection('addcase')
        .where('team', arrayContains: lawyerId)
        .where('casetype', isEqualTo: 'closed')
        .snapshots()
        .listen((snapshot) {
      List<Map<String, dynamic>> closedCases = snapshot.docs
          .where((doc) => doc['team'][0] == lawyerId)
          .map((doc) => doc.data())
          .toList();
      setState(() {
        closedCasesLists = closedCases;
      });
    });
  }

  void upcomingCasesList() {
    FirebaseFirestore.instance
        .collection('addcase')
        .where('team', arrayContains: lawyerId)
        .where('casetype', isEqualTo: 'upcoming')
        .snapshots()
        .listen((snapshot) {
      List<Map<String, dynamic>> upcomingCases = snapshot.docs
          .where((doc) => doc['team'][0] == lawyerId)
          .map((doc) => doc.data())
          .toList();
      setState(() {
        upcomingCasesLists = upcomingCases;
      });
    });
  }

  void handleCaseTap(int index) {
    setState(() {
      if (selectedCaseIndex == index) {
        selectedCaseIndex = -1;
        isListViewVisible = false;
      } else {
        selectedCaseIndex = index;
        isListViewVisible = true;
      }
    });
  }

  void handleCaseTapCancel() {
    setState(() {
      selectedCaseIndex = -1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.only(top: 85),
        child: Column(
          children: [
            const Text(
              "JURIDENT",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: 30,
                fontFamily: 'Satoshi',
                fontWeight: FontWeight.w500,
                fontStyle: FontStyle.normal,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () => handleCaseTap(0),
                  onTapCancel: handleCaseTapCancel,
                  child: Container(
                    decoration: BoxDecoration(
                      color: selectedCaseIndex == 0
                          ? const Color(0xffC99F4A)
                          : const Color(0xff050125),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    width: 120,
                    height: 120,
                    child: Center(
                      child: Text(
                        '${openCasesLists.length} \nOpen\ncases',
                        style: TextStyle(
                          fontSize: 20,
                          color: selectedCaseIndex == 0
                              ? Colors.black
                              : const Color(0xffC99F4A),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                GestureDetector(
                  onTap: () => handleCaseTap(1),
                  onTapCancel: handleCaseTapCancel,
                  child: Container(
                    decoration: BoxDecoration(
                      color: selectedCaseIndex == 1
                          ? const Color(0xffC99F4A)
                          : const Color(0xff050125),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    width: 120,
                    height: 120,
                    child: Center(
                      child: Text(
                        '${closedCasesLists.length} \nClosed\ncases',
                        style: TextStyle(
                          fontSize: 20,
                          color: selectedCaseIndex == 1
                              ? Colors.black
                              : const Color(0xffC99F4A),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                GestureDetector(
                  onTap: () => handleCaseTap(2),
                  onTapCancel: handleCaseTapCancel,
                  child: Container(
                    decoration: BoxDecoration(
                      color: selectedCaseIndex == 2
                          ? const Color(0xffC99F4A)
                          : const Color(0xff050125),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    width: 120,
                    height: 120,
                    child: Center(
                      child: Text(
                        '${upcomingCasesLists.length} \nUpcoming\ncases',
                        style: TextStyle(
                          fontSize: 20,
                          color: selectedCaseIndex == 2
                              ? Colors.black
                              : const Color(0xffC99F4A),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            if (isListViewVisible && selectedCaseIndex == 0)
              SizedBox(
                height: 615,
                width: 380,
                child: ListView.separated(
                  physics: const BouncingScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) =>
                      const SizedBox(height: 10),
                  itemCount: openCasesLists.length,
                  itemBuilder: (context, index) {
                    Map<String, dynamic> caseData = openCasesLists[index];

                    final caseName = caseData['caseName'] ?? '';
                    final partyName = caseData['partyName'] ?? '';
                    final caseNumber = caseData['caseNo'] ?? '';
                    return LandingItemWidget(
                      caseName: caseName,
                      partyName: partyName,
                      caseNumber: caseNumber,
                      caseType: 'open',
                    );
                  },
                ),
              ),
            if (isListViewVisible && selectedCaseIndex == 1)
              SizedBox(
                height: 615,
                width: 380,
                child: ListView.separated(
                  physics: const BouncingScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) =>
                      const SizedBox(height: 10),
                  itemCount: closedCasesLists.length,
                  itemBuilder: (context, index) {
                    Map<String, dynamic> caseData = closedCasesLists[index];
                    final caseName = caseData['caseName'] ?? '';
                    final partyName = caseData['partyName'] ?? '';
                    final caseNumber = caseData['caseNo'] ?? '';
                    return LandingItemWidget(
                      caseType: 'closed',
                      caseName: caseName,
                      partyName: partyName,
                      caseNumber: caseNumber,
                    );
                  },
                ),
              ),
            if (isListViewVisible && selectedCaseIndex == 2)
              SizedBox(
                height: 615,
                width: 380,
                child: ListView.separated(
                  physics: const BouncingScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) =>
                      const SizedBox(height: 10),
                  itemCount: upcomingCasesLists.length,
                  itemBuilder: (context, index) {
                    Map<String, dynamic> caseData = upcomingCasesLists[index];
                    final caseName = caseData['caseName'] ?? '';
                    final partyName = caseData['partyName'] ?? '';
                    final caseNumber = caseData['caseNo'] ?? '';
                    return LandingItemWidget(
                      caseType: 'upcoming',
                      caseName: caseName,
                      partyName: partyName,
                      caseNumber: caseNumber,
                    );
                  },
                ),
              ),
              
          ],
        ),
      ),
    );
  }
}
