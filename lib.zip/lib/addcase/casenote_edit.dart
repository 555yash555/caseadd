import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CustomeCaseNotes extends StatefulWidget {
  final String caseId;
  final String casetype;

  const CustomeCaseNotes({
    Key? key,
    required this.caseId,
    required this.casetype,
  }) : super(key: key);

  @override
  _CustomeCaseNotesState createState() => _CustomeCaseNotesState();
}

class _CustomeCaseNotesState extends State<CustomeCaseNotes> {
  late TextEditingController _notesController;

  @override
  void initState() {
    super.initState();
    _notesController = TextEditingController();
    fetchCaseNotes();
  }

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> fetchCaseNotes() async {
    try {
      final DocumentSnapshot<Map<String, dynamic>> snapshot =
          await FirebaseFirestore.instance
              .collection('addcase')
              .doc(widget.caseId)
              .get();

      if (snapshot.exists) {
        final Map<String, dynamic> caseData = snapshot.data()!;
        final String caseNotes = caseData['casenotes'] ?? '';
        _notesController.text = caseNotes;
      }
    } catch (error) {
      print('Error fetching case notes: $error');
    }
  }

  Future<void> updateCaseNotes(String updatedNotes) async {
    try {
      await FirebaseFirestore.instance
          .collection('addcase')
          .doc(widget.caseId)
          .update({'casenotes': updatedNotes});

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Case notes updated successfully')),
      );
    } catch (error) {
      print('Error updating case notes: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () {
        showModalBottomSheet<dynamic>(
          isScrollControlled: true,
          context: context,
          builder: ((context) {
            return Wrap(
              children: [
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: screenHeight * 0.014),
                      Padding(
                        padding: EdgeInsets.only(
                          left: screenWidth * 0.311,
                          right: screenWidth * 0.311,
                        ),
                        child: Divider(
                          color: darkModeButtonColor,
                          thickness: 3,
                          height: 7,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          left: screenWidth * 0.07,
                          top: screenHeight * 0.024,
                        ),
                        child: Row(
                          children: [
                            const Text(
                              "Case Notes",
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w600,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(width: screenWidth * 0.3),
                            Container(
                              height: screenHeight * 0.04,
                              decoration: BoxDecoration(
                                color: themeProvider.isDarkMode
                                    ? backColor
                                    : darkModeButtonColor,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Center(
                                child: Padding(
                                  padding: EdgeInsets.all(8.0),
                                  child: Text(
                                    "Save as Draft",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.039),
                      Padding(
                        padding: EdgeInsets.only(left: screenWidth * 0.07),
                        child: Text(
                          "${widget.lawyerName}'s Case Notes",
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          left: screenWidth * 0.07,
                          top: screenHeight * 0.024,
                        ),
                        child: Text(
                          widget.time,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w400,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: screenHeight * 0.01,
                          left: screenWidth * 0.07,
                          right: screenWidth * 0.07,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: TextFormField(
                            controller: _notesController,
                            onChanged: (value) {
                              // Update the case notes when the text changes
                              updateCaseNotes(value);
                            },
                            maxLines: 18,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w200,
                            ),
                            decoration: InputDecoration(
                              fillColor: formFillColor,
                              filled: true,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              hintText: "Add your case notes",
                              hintStyle: const TextStyle(
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.016),
                      Padding(
                        padding: EdgeInsets.only(
                          left: screenWidth * 0.07,
                          right: screenWidth * 0.07,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: formFillColor,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              TextButton(
                                onPressed: () {},
                                child: const Text(
                                  "B",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                              TextButton(
                                onPressed: () {},
                                child: const Text(
                                  "/",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                              TextButton(
                                onPressed: () {},
                                child: const Text(
                                  "U",
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                              SizedBox(width: screenWidth * 0.067),
                              InkWell(
                                onTap: () {},
                                child: Container(
                                  height: 20,
                                  width: 20,
                                  decoration: BoxDecoration(
                                    border: Border.all(),
                                    borderRadius: BorderRadius.circular(20),
                                    color: Colors.red,
                                  ),
                                  child: const Text(""),
                                ),
                              ),
                              SizedBox(width: screenWidth * 0.067),
                              IconButton(
                                onPressed: () {},
                                icon: const Icon(
                                  Icons.menu_outlined,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ],
            );
          }),
        );
      },
      child: const Text("Show case notes"),
    );
  }
}
