import 'package:flutter/material.dart';

Color backColor = const Color.fromRGBO(5, 1, 37, 1);
Color toggleColor = const Color.fromRGBO(49, 80, 127, 1);
Color darkModeButtonColor= const Color.fromRGBO(201, 159, 74, 1);
Color caseNotesBackgroundColor = const Color.fromRGBO(217, 217, 217, 1);
Color formFillColor = const Color.fromRGBO(51, 51, 51, 1);