import 'package:flutter/material.dart';
import 'casenotes.dart';

class EditCaseDetailsPage extends StatefulWidget {
  final String caseNumber;
  final String caseName;
  final String partyName;
  final String courtName;
  final String hearingDate;
  final String partyContactNo;
  final String adverseParty;
  final String adversePartyContactNo;
  final String adversePartyLawyer;
  final String caseType;
  final Function(BuildContext, Map<String, dynamic>) onUpdate;

  const EditCaseDetailsPage({
    Key? key,
    required this.caseNumber,
    required this.caseName,
    required this.partyName,
    required this.courtName,
    required this.hearingDate,
    required this.partyContactNo,
    required this.adverseParty,
    required this.adversePartyContactNo,
    required this.adversePartyLawyer,
    required this.onUpdate, 
    required this.caseType,
  }) : super(key: key);

  @override
  _EditCaseDetailsPageState createState() => _EditCaseDetailsPageState();
}

class _EditCaseDetailsPageState extends State<EditCaseDetailsPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _courtNameController = TextEditingController();
  final TextEditingController _hearingDateController = TextEditingController();
  final TextEditingController _partyContactNoController = TextEditingController();
  final TextEditingController _adversePartyController = TextEditingController();
  final TextEditingController _adversePartyContactNoController = TextEditingController();
  final TextEditingController _adversePartyLawyerController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _courtNameController.text = widget.courtName;
    _hearingDateController.text = widget.hearingDate;
    _partyContactNoController.text = widget.partyContactNo;
    _adversePartyController.text = widget.adverseParty;
    _adversePartyContactNoController.text = widget.adversePartyContactNo;
    _adversePartyLawyerController.text = widget.adversePartyLawyer;
  }

  @override
  void dispose() {
    _courtNameController.dispose();
    _hearingDateController.dispose();
    _partyContactNoController.dispose();
    _adversePartyController.dispose();
    _adversePartyContactNoController.dispose();
    _adversePartyLawyerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Case Details'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _courtNameController,
                decoration: InputDecoration(labelText: 'Court Name'),
              ),
              TextFormField(
                controller: _hearingDateController,
                decoration: InputDecoration(labelText: 'Hearing Date'),
              ),
              TextFormField(
                controller: _partyContactNoController,
                decoration: InputDecoration(labelText: 'Party Contact No'),
              ),
              TextFormField(
                controller: _adversePartyController,
                decoration: InputDecoration(labelText: 'Adverse Party'),
              ),
              TextFormField(
                controller: _adversePartyContactNoController,
                decoration: InputDecoration(labelText: 'Adverse Party Contact No'),
              ),
              TextFormField(
                controller: _adversePartyLawyerController,
                decoration: InputDecoration(labelText: 'Adverse Party Lawyer'),
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
         
                onPressed: () {
                         print('save button');
                  if (_formKey.currentState!.validate()) {
                    final Map<String, dynamic> updatedData = {
                      'courtName': _courtNameController.text,
                      'hearingDate': _hearingDateController.text,
                      'partyContactNo': _partyContactNoController.text,
                      'adverseParty': _adversePartyController.text,
                      'adversePartyContactNo': _adversePartyContactNoController.text,
                      'adversePartyLawyer': _adversePartyLawyerController.text,
                    };

                    // Call the onUpdate callback function with the updated data
                    widget.onUpdate(context, updatedData);
                  }
                },
                child: Text('Save'),
              ),
                      InkWell(
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    builder: (context) => const CustomeCaseNotes(
                      lawyerName: "John Doe",
                      time: "2023-06-17 10:00 AM",
                    ),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.only(left: 100),
                  width: 174,
                  decoration: BoxDecoration(
                    color: const Color(0xffFFEABE),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text(
                      'Add case notes',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
