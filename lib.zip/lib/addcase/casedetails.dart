import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'editcase.dart';

class CaseDetailsPage extends StatefulWidget {
  final String caseNumber;
  final String caseName;
  final String partyName;
  
  final String caseType;

  const CaseDetailsPage({
    Key? key,
    required this.caseNumber,
    required this.caseName,
    required this.partyName, 
    required this. caseType,
  }) : super(key: key);

  @override
  _CaseDetailsPageState createState() => _CaseDetailsPageState();
}

class _CaseDetailsPageState extends State<CaseDetailsPage> {
  Map<String, dynamic>? caseData;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchCaseDetails();
  }

  void fetchCaseDetails() async {
    try {
      final QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('addcase')
          .where('caseNo', isEqualTo: widget.caseNumber)
          .where('caseName', isEqualTo: widget.caseName)
          .where('partyName', isEqualTo: widget.partyName)
          .get();

      if (snapshot.docs.isNotEmpty) {
        final DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
            snapshot.docs.first as DocumentSnapshot<Map<String, dynamic>>;

        setState(() {
          caseData = documentSnapshot.data();
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (error) {
      print('Failed to fetch case details: $error');
      setState(() {
        isLoading = false;
      });
    }
  }

void updateCaseDetails(BuildContext context, Map<String, dynamic> updatedData) async {
  try {
    print('update');
    print(updatedData);
    final CollectionReference casesCollection =
        FirebaseFirestore.instance.collection('addcase');

    final QuerySnapshot<Object?> snapshot =
        await casesCollection
            .where('caseNo', isEqualTo: widget.caseNumber)
            .where('casetype', isEqualTo: widget.caseType)
            .get();

    if (snapshot.docs.isNotEmpty) {
      final DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
          snapshot.docs.first as DocumentSnapshot<Map<String, dynamic>>;

      // Update the fields with the updatedData
      final Map<String, dynamic> currentData = documentSnapshot.data()!;
      final Map<String, dynamic> newData = {
        ...currentData,
        ...updatedData,
      };

      await documentSnapshot.reference.update(newData);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Case details updated successfully')),
      );

      // Refresh case details
      fetchCaseDetails();
    }
  } catch (error) {
    print('error $error');
  }
}

@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Case Details'),
        actions: [
          TextButton.icon(
            onPressed: () {
              if (!isLoading && caseData != null) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EditCaseDetailsPage(
                      caseNumber: widget.caseNumber,
                      caseName: widget.caseName,
                      partyName: widget.partyName,
                      courtName: caseData!['courtName'] ?? '',
                      hearingDate: caseData!['hearingDate'] ?? '',
                      partyContactNo: caseData!['partyContactNo'] ?? '',
                      adverseParty: caseData!['adverseParty'] ?? '',
                      adversePartyContactNo: caseData!['adversePartyContactNo'] ?? '',
                      adversePartyLawyer: caseData!['adversePartyLawyer'] ?? '',
                      onUpdate: updateCaseDetails,
                      caseType: widget.caseType,
                    ),
                  ),
                );
              }
            },
            icon: Icon(Icons.edit, color: Colors.amber),
            label: Text('Edit'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : caseData != null
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Case Number: ${widget.caseNumber}'),
                      Text('Case Name: ${widget.caseName}'),
                      Text('Party Name: ${widget.partyName}'),
                      SizedBox(height: 16.0),
                      Text('Court Name: ${caseData!['courtName']}'),
                      Text('Hearing Date: ${caseData!['hearingDate']}'),
                      Text('Party Contact No: ${caseData!['partyContactNo']}'),
                      Text('Adverse Party: ${caseData!['adverseParty']}'),
                      Text('Adverse Party Contact No: ${caseData!['adversePartyContactNo']}'),
                      Text('Adverse Party Lawyer: ${caseData!['adversePartyLawyer']}'),
                    ],
                  )
                : Center(child: Text('Failed to fetch case details')),
      ),
    );
  }
}